package com.example.demo.Service;

import java.sql.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Endity.Endereço;
import com.example.demo.Endity.Pessoa;
import com.example.demo.Repository.EndereçoRepository;
import com.example.demo.Repository.PessoaRepository;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
public class PessoaService {


    @Autowired
private ObjectMapper objectMapper;

public Pessoa getPessoaFromJson(String json) throws JsonMappingException, JsonProcessingException {
    return objectMapper.readValue(json, Pessoa.class);
}

       @Autowired
    private PessoaRepository pessoaRepository;
    @Autowired
    private EndereçoRepository enderecoRepository;

    public List<Pessoa> findPessoasByNome(String nome) {
        return pessoaRepository.findPessoasByNome(nome);
    }

    public List<Pessoa> findPessoasByDataNascimento(Date dataInicial, Date dataFinal) {
        return pessoaRepository.findPessoasByDataNascimento(dataInicial, dataFinal);
    }

    public List<Endereço> findEnderecosByLogradouro(String logradouro) {
        return enderecoRepository.findEnderecosByLogradouro(logradouro);
    }

    public List<Endereço> findEnderecosByCep(String cep) {
        return enderecoRepository.findEnderecosByCep(cep);
    }

    public List<Endereço> findEnderecosByNumero(int numero) {
        return enderecoRepository.findEnderecosByNumero(numero);
    }

    public List<Endereço> findEnderecosByCidade(String cidade) {
        return enderecoRepository.findEnderecosByCidade(cidade);
    }

    public List<Endereço> findEnderecosByEstado(String estado) {
        return EndereçoRepository.findEnderecosByEstado(estado);
    }

    public void createPessoa(Pessoa pessoa2) {
        throw new UnsupportedOperationException("Unimplemented method 'createPessoa'");
    }


}
