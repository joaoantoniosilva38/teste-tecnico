package com.example.demo.Repository;

import java.sql.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.example.demo.Endity.Pessoa;

public interface PessoaRepository extends JpaRepository<Pessoa, Integer> {
    @Query("SELECT p FROM Pessoa p WHERE p.nome LIKE %:nome%")
    List<Pessoa> findPessoasByNome(@Param("nome") String nome);


    @Query("SELECT p FROM Pessoa p WHERE p.dataNascimento BETWEEN :dataInicial AND :dataFinal")
    List<Pessoa> findPessoasByDataNascimento(@Param("dataInicial") Date dataInicial, @Param("dataFinal") Date dataFinal); 
 
    
}
    
 

