package com.example.demo.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.example.demo.Endity.Endereço;

public interface EndereçoRepository extends JpaRepository<Endereço, Integer> {
    @Query("SELECT e FROM Endereco e WHERE e.logradouro LIKE %:logradouro%")
    List<Endereço> findEnderecosByLogradouro(@Param("logradouro") String logradouro);

    @Query("SELECT e FROM Endereco e WHERE e.cep = :cep")
    List<Endereço> findEnderecosByCep(@Param("cep") String cep);

    @Query("SELECT e FROM Endereco e WHERE e.numero = :numero")
    List<Endereço> findEnderecosByNumero(@Param("numero") int numero);

    @Query("SELECT e FROM Endereco e WHERE e.cidade = :cidade")
    List<Endereço> findEnderecosByCidade(@Param("cidade") String cidade);

    @Query("SELECT e FROM Endereco e WHERE e.estado = :estado")
    static
    List<Endereço> findEnderecosByEstado(@Param("estado") String estado) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'findEnderecosByEstado'");
    }

   
}
