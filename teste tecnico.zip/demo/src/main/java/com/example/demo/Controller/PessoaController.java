package com.example.demo.Controller;

import java.sql.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.Endity.Endereço;
import com.example.demo.Endity.Pessoa;
import com.example.demo.Service.PessoaService;

@RestController
@RequestMapping("/pessoas")
public class PessoaController {
    
      @Autowired
    private PessoaService pessoaService;

    @GetMapping("/nome/{nome}")
    public List<Pessoa> findPessoasByNome(@PathVariable String nome) {
        return pessoaService.findPessoasByNome(nome);
    }

    @GetMapping("/data-nascimento/{dataInicial}/{dataFinal}")
    public List<Pessoa> findPessoasByDataNascimento(@PathVariable Date dataInicial, @PathVariable Date dataFinal) {
        return pessoaService.findPessoasByDataNascimento(dataInicial, dataFinal);
    }

    @GetMapping("/enderecos/logradouro/{logradouro}")
    public List<Endereço> findEnderecosByLogradouro(@PathVariable String logradouro) {
        return pessoaService.findEnderecosByLogradouro(logradouro);
    }

    @GetMapping("/enderecos/cep/{cep}")
    public List<Endereço> findEnderecosByCep(@PathVariable String cep) {
        return pessoaService.findEnderecosByCep(cep);
    }

    @GetMapping("/enderecos/numero/{numero}")
    public List<Endereço> findEnderecosByNumero(@PathVariable int numero) {
        return pessoaService.findEnderecosByNumero(numero);
    }

    @GetMapping("/enderecos/cidade/{cidade}")
    public List<Endereço> findEnderecosByCidade(@PathVariable String cidade) {
        return pessoaService.findEnderecosByCidade(cidade);
    }

    @GetMapping("/enderecos/estado/{estado}")
    public List<Endereço> findEnderecosByEstado(@PathVariable String estado) {
        return pessoaService.findEnderecosByEstado(estado);
    }
}
