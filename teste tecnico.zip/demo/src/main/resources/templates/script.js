// Função para abrir modal
function openModal(modalId) {
    var modal = document.getElementById('modal-' + modalId);
    modal.style.display = 'block';
}

// Função para fechar modal
function closeModal(modalId) {
    var modal = document.getElementById('modal-' + modalId);
    modal.style.display = 'none';
}

// Função para criar pessoa
document.getElementById('create-form').addEventListener('submit', function(event) {
    event.preventDefault();
    // Simulando sucesso ao criar pessoa
    alert('Pessoa criada com sucesso!');
    closeModal('create');
});

// Função para abrir modal de busca
function openModalSearch() {
    var modal = document.getElementById('modal-search');
    modal.style.display = 'block';

    // Preenche a lista com todas as pessoas
    fillPeopleList(people);
}

// Função para preencher a lista de pessoas
function fillPeopleList(people) {
    var list = document.getElementById('people-list');
    list.innerHTML = ''; // Limpa a lista

    // Preenche a lista com as pessoas
    people.forEach(function(person) {
        var listItem = document.createElement('li');
        listItem.innerHTML = `
            <strong>Nome Completo:</strong> ${person.name} <br>
            <strong>Data de Nascimento:</strong> ${person.birthdate} <br>
            <strong>Endereço:</strong> <br>
            - Logradouro: ${person.address.logradouro} <br>
            - CEP: ${person.address.cep} <br>
            - Número: ${person.address.numero} <br>
            - Cidade: ${person.address.cidade} <br>
            - Estado: ${person.address.estado} <br>
            <button onclick="openModal('edit')">Editar</button> 
            <button onclick="openModal('delete')">Excluir</button>
        `;
        list.appendChild(listItem);
    });
}

// Função para preencher o formulário de edição com os dados da pessoa selecionada
function fillEditForm(person) {
    document.getElementById('edit-name').value = person.name;
    document.getElementById('edit-birthdate').value = person.birthdate;
    document.getElementById('edit-logradouro').value = person.address.logradouro;
    document.getElementById('edit-cep').value = person.address.cep;
    document.getElementById('edit-numero').value = person.address.numero;
    document.getElementById('edit-cidade').value = person.address.cidade;
    document.getElementById('edit-estado').value = person.address.estado;
}

// Supondo que você tenha uma função para editar uma pessoa chamada editPerson()
function editPerson() {
    // Lógica para editar a pessoa...

    // Após a edição, feche o modal de edição
    closeModal('edit');
}

// Função para remover os dados do modal de consulta
function clearSearchModal() {
    var list = document.getElementById('people-list');
    list.innerHTML = ''; // Limpa a lista de pessoas
}

// Função para remover os dados da pessoa da tela
function removePersonFromScreen(personName) {
    var list = document.getElementById('people-list');
    var items = list.getElementsByTagName('li');

    // Itera sobre os itens da lista
    for (var i = 0; i < items.length; i++) {
        var item = items[i];
        var itemName = item.querySelector('strong').innerText.split(':')[1].trim(); // Extrai o nome da pessoa

        // Se o nome da pessoa corresponder, remove o elemento da lista
        if (itemName === personName) {
            list.removeChild(item);
            break; // Encerra o loop após encontrar e remover o item
        }
    }

    // Fecha o modal após excluir a pessoa
    closeModal('search');
}


var people = [
    {
        name: "João da Silva",
        birthdate: "1990-05-15",
        address: {
            logradouro: "Rua das Flores",
            cep: "12345-678",
            numero: "123",
            cidade: "São Paulo",
            estado: "SP"
        }
    },
    // Adicione outras pessoas aqui conforme necessário
];

// Preencher as opções do menu suspenso de exclusão
fillDeleteDropdown(people);

// Função para confirmar a exclusão da pessoa selecionada
function confirmDelete() {
    var dropdown = document.getElementById('delete-person');
    var selectedPerson = dropdown.value;

}




