package com.example.demo;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.sql.Date;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.example.demo.Endity.Pessoa;
import com.example.demo.Service.PessoaService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@RunWith(SpringRunner.class)
@SpringBootTest
public class PossoaServiceTest<Endereco> {
    

    @Autowired
    private ObjectMapper objectMapper;
    
    public Pessoa getPessoaFromJson(String json) throws JsonMappingException, JsonProcessingException {
        return objectMapper.readValue(json, Pessoa.class);
    }


     @Autowired
    private PessoaService pessoaService;

    @Test
    public void testFindPessoasByNome() {
        // given
        Pessoa pessoa1 = new Pessoa();
        pessoa1.setNome("João");
        pessoaService.createPessoa(pessoa1);

        Pessoa pessoa2 = new Pessoa();
        pessoa2.setNome("Maria");
        pessoaService.createPessoa(pessoa2);

        // when
        List<Pessoa> pessoas = pessoaService.findPessoasByNome("João");

        // then
        assertEquals(1, pessoas.size());
        assertEquals("João", pessoas.get(0).getNome());
    }

    @Test
    public void testFindPessoasByDataNascimento() {
        // given
        Pessoa pessoa1 = new Pessoa();
        pessoa1.setNome("João");
        pessoa1.setDataNascimento(Date.valueOf("2000-01-01"));
        pessoaService.createPessoa(pessoa1);

        Pessoa pessoa2 = new Pessoa();
        pessoa2.setNome("Maria");
        pessoa2.setDataNascimento(Date.valueOf("2001-01-01"));
        pessoaService.createPessoa(pessoa2);

        // when
        List<Pessoa> pessoas = pessoaService.findPessoasByDataNascimento(Date.valueOf("2000-01-01"), Date.valueOf("2000-12-31"));

        // then
        assertEquals(1, pessoas.size());
        assertEquals("João", pessoas.get(0).getNome());
    }

   
 
 
}
