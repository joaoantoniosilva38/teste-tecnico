package com.example.demo;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.sql.Date;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.example.demo.Endity.Pessoa;
import com.example.demo.Repository.PessoaRepository;

@RunWith(SpringRunner.class)
@DataJpaTest
public class PessoaRepositoryTesT {
    
     @Autowired
    private PessoaRepository pessoaRepository;

    @Test
    public void testFindPessoasByNome() {
        // given
        Pessoa pessoa1 = new Pessoa();
        pessoa1.setNome("João");
        pessoaRepository.save(pessoa1);

        Pessoa pessoa2 = new Pessoa();
        pessoa2.setNome("Maria");
        pessoaRepository.save(pessoa2);

        // when
        List<Pessoa> pessoas = pessoaRepository.findPessoasByNome("João");

        // then
        assertEquals(1, pessoas.size());
        assertEquals("João", pessoas.get(0).getNome());
    }

    @Test
    public void testFindPessoasByDataNascimento() {
        // given
        Pessoa pessoa1 = new Pessoa();
        pessoa1.setNome("João");
        pessoa1.setDataNascimento(Date.valueOf("2000-01-01"));
        pessoaRepository.save(pessoa1);

        Pessoa pessoa2 = new Pessoa();
        pessoa2.setNome("Maria");
        pessoa2.setDataNascimento(Date.valueOf("2001-01-01"));
        pessoaRepository.save(pessoa2);

        // when
        List<Pessoa> pessoas = pessoaRepository.findPessoasByDataNascimento(Date.valueOf("2000-01-01"), Date.valueOf("2000-12-31"));

        // then
        assertEquals(1, pessoas.size());
        assertEquals("João", pessoas.get(0).getNome());
    }
}
